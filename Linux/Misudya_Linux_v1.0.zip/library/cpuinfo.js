/*
Misudya CPU Information Return

API: /cpuinfo
VALVE: 
AUTHOR: Reyrmth
LATETIME: 20260419/1:24:44 UTC+8
*/

const fs = require('fs').promises;
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
module.exports = {
  route: '/cpuinfo',
  async execute(query, method, context) {
    const result = {
      'cpu-usage': '0%',
      'cpu-cores': '0'
    };
    try {
      try {
        const cpuinfo = await fs.readFile('/proc/cpuinfo', 'utf8');
        const lines = cpuinfo.split('\n');
        let model = 'unknown';
        let cores = 0;
        const uniqueCores = new Set();
        for (const line of lines) {
          if (line.startsWith('model name')) {
            model = line.split(':')[1].trim();
          }
          if (line.startsWith('processor')) {
            const coreId = line.split(':')[1].trim();
            uniqueCores.add(coreId);
          }
        }
        cores = uniqueCores.size;
        result['cpu-cores'] = cores.toString();
        result['cpu-model'] = model;
        for (let i = 1; i <= cores; i++) {
          result['cpu-core' + i] = '0%';
        }
        
      } catch (e) {
        result['cpu-model'] = 'unknown';
      }
      try {
        const uptime = await fs.readFile('/proc/uptime', 'utf8');
        const seconds = Math.floor(parseFloat(uptime.split(' ')[0]));
        result['cpu-runtimes'] = seconds.toString();
      } catch (e) {
        result['cpu-runtimes'] = '0';
      }
      try {
        const getCoreStats = async () => {
          const data = await fs.readFile('/proc/stat', 'utf8');
          const lines = data.split('\n');
          const cores = [];
          for (const line of lines) {
            if (line.startsWith('cpu')) {
              const parts = line.trim().split(/\s+/);
              const name = parts[0];
              const values = parts.slice(1).map(Number);
              if (name === 'cpu') {
                cores[0] = {
                  name: name,
                  user: values[0],
                  nice: values[1],
                  system: values[2],
                  idle: values[3],
                  iowait: values[4],
                  irq: values[5],
                  softirq: values[6]
                };
              } else if (name.startsWith('cpu')) {
                const coreNum = parseInt(name.replace('cpu', '')) + 1;
                cores[coreNum] = {
                  name: name,
                  coreNum: coreNum,
                  user: values[0],
                  nice: values[1],
                  system: values[2],
                  idle: values[3],
                  iowait: values[4],
                  irq: values[5],
                  softirq: values[6]
                };
              }
            }
          }
          return cores;
        };
        const stat1 = await getCoreStats();
        await new Promise(r => setTimeout(r, 800));
        const stat2 = await getCoreStats();
        if (stat1[0] && stat2[0]) {
          const total1 = stat1[0].user + stat1[0].nice + stat1[0].system + stat1[0].idle + stat1[0].iowait + stat1[0].irq + stat1[0].softirq;
          const total2 = stat2[0].user + stat2[0].nice + stat2[0].system + stat2[0].idle + stat2[0].iowait + stat2[0].irq + stat2[0].softirq;
          const totalDiff = total2 - total1;
          const idleDiff = stat2[0].idle - stat1[0].idle;
          const usage = totalDiff > 0 ? ((totalDiff - idleDiff) / totalDiff * 100).toFixed(0) : 0;
          result['cpu-usage'] = usage + '%';
        }
        const coreCount = parseInt(result['cpu-cores']);
        for (let i = 1; i <= coreCount; i++) {
          if (stat1[i] && stat2[i]) {
            const s1 = stat1[i];
            const s2 = stat2[i];
            const total1 = s1.user + s1.nice + s1.system + s1.idle + s1.iowait + s1.irq + s1.softirq;
            const total2 = s2.user + s2.nice + s2.system + s2.idle + s2.iowait + s2.irq + s2.softirq;
            const totalDiff = total2 - total1;
            const idleDiff = s2.idle - s1.idle;
            const usage = totalDiff > 0 ? ((totalDiff - idleDiff) / totalDiff * 100).toFixed(0) : 0;
            result['cpu-core' + i] = usage + '%';
          }
        }
      } catch (e) {
        result['cpu-usage'] = 'error';
      }
      try {
        const { stdout } = await execAsync('ps aux --sort=-%cpu | head -2 | tail -1');
        const parts = stdout.trim().split(/\s+/);
        if (parts.length >= 11) {
          const command = parts.slice(10).join(' ');
          result['cpu-hightasks'] = command.length > 20 ? command.substring(0, 20) + '...' : command;
        } else {
          result['cpu-hightasks'] = 'none';
        }
      } catch (e) {
        result['cpu-hightasks'] = 'unknown';
      }
      return result;
    } catch (err) {
      throw new Error('Failed to get CPU information: ' + err.message);
    }
  }
};
