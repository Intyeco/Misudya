/*
Misudya Space Information Return

API: /space
VALVE: 
AUTHOR: Reyrmth
LATETIME: 20260419/1:42:44 UTC+8
*/


const fs = require('fs').promises;
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
module.exports = {
  route: '/spaceinfo',
  async execute(query, method, context) {
    const result = {
      'space-usage': '0%',
      'space-type': 'unknown',
      'space-devices': '0',
      'space-model': 'unknown'
    };
    try {
      const devices = [];
      try {
        const { stdout: lsblk } = await execAsync('lsblk -d -o NAME,TYPE,MODEL,SIZE,ROTA -J 2>/dev/null || lsblk -d -o NAME,TYPE,MODEL,SIZE,ROTA');
        let blkData;
        try {
          blkData = JSON.parse(lsblk);
        } catch (e) {
          blkData = { blockdevices: [] };
          const lines = lsblk.trim().split('\n').slice(1);
          for (const line of lines) {
            const parts = line.trim().split(/\s+/);
            if (parts.length >= 3) {
              blkData.blockdevices.push({
                name: parts[0],
                type: parts[1],
                model: parts.slice(2, -2).join(' ') || 'unknown',
                size: parts[parts.length - 2] || '0',
                rota: parts[parts.length - 1] || '1'
              });
            }
          }
        }
        const disks = blkData.blockdevices ? blkData.blockdevices.filter(d => d.type === 'disk') : [];
        result['space-devices'] = disks.length.toString();
        let hasSSD = false;
        let hasNVMe = false;
        let hasEMMC = false;
        let hasUFS = false;
        let hasHDD = false;
        for (const disk of disks) {
          const name = disk.name || '';
          const model = (disk.model || '').toLowerCase();
          if (name.startsWith('nvme')) {
            hasNVMe = true;
          }
          else if (name.startsWith('mmcblk')) {
            hasEMMC = true;
          }
          else if (model.includes('ufs') || name.includes('ufs')) {
            hasUFS = true;
          }
          else if (disk.rota === '0' || disk.rota === 0) {
            hasSSD = true;
          }
          else {
            hasHDD = true;
          }
          if (result['space-model'] === 'unknown' && disk.model && disk.model !== 'unknown') {
            result['space-model'] = disk.model;
          }
        }
        if (hasNVMe) {
          result['space-type'] = 'NVMe SSD';
        } else if (hasUFS) {
          result['space-type'] = 'UFS';
        } else if (hasEMMC) {
          result['space-type'] = 'eMMC';
        } else if (hasSSD) {
          result['space-type'] = 'SSD';
        } else if (hasHDD) {
          result['space-type'] = 'HDD';
        }
        const { stdout: dfInfo } = await execAsync('df -h | grep -E \'^/dev\'');
        const dfLines = dfInfo.trim().split('\n');
        let totalPercent = 0;
        let mountCount = 0;
        let deviceIndex = 1;
        for (const line of dfLines) {
          const parts = line.trim().split(/\s+/);
          if (parts.length >= 6) {
            const device = parts[0];
            const usage = parts[4];
            const percentNum = parseInt(usage.replace('%', '')) || 0;
            totalPercent += percentNum;
            mountCount++;
            result['space-usage' + deviceIndex] = usage;
            deviceIndex++;
          }
        }
        if (mountCount > 0) {
          result['space-usage'] = Math.round(totalPercent / mountCount) + '%';
        }
        if (deviceIndex === 1) {
          result['space-usage1'] = 'N/A';
        }
      } catch (e) {
        try {
          const { stdout } = await execAsync('df -h / | tail -1');
          const parts = stdout.trim().split(/\s+/);
          if (parts.length >= 5) {
            result['space-usage'] = parts[4];
            result['space-usage1'] = parts[4];
            result['space-devices'] = '1';
          }
        } catch (e2) {
        }
      }
      return result;
    } catch (err) {
      throw new Error('Failed to get Space information: ' + err.message);
    }
  }
};
