/*
Misudya Easy Console

API: /console
VALVE: command
AUTHOR: Reyrmth
LATETIME: 20260419/2:13:59 UTC+8
*/

const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
module.exports = {
  route: '/console',
  async execute(query, method, context) {
    const { command } = query;
    if (!command) {
      throw new Error('NOT_VALUE_COMMAND');
    }
    const decodedCommand = decodeURIComponent(command);
    try {
      const result = await execAsync(decodedCommand, {
        timeout: 30000,
        maxBuffer: 1024 * 1024,
        shell: '/bin/bash'
      });
      const stdout = result.stdout ? result.stdout : '';
      const stderr = result.stderr ? result.stderr : '';
      const output = stdout + (stderr ? '\n' + stderr : '');
      return {
        success: true,
        return: output
      };
      
    } catch (error) {
      const stdout = error.stdout ? error.stdout : '';
      const stderr = error.stderr ? error.stderr : error.message;
      const output = stdout + (stderr ? '\n' + stderr : '');
      return {
        success: false,
        return: output
      };
    }
  }
};
