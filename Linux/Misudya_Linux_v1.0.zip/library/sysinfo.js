/*
Misudya System Information Return

API: /sysinfo
VALVE: 
AUTHOR: Reyrmth
LATETIME: 20260419/1:54:44 UTC+8
*/

const fs = require('fs').promises;
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
module.exports = {
  route: '/sysinfo',
  async execute(query, method, context) {
    const result = {
      'system-kernel': 'unknown',
      'system-version': 'unknown',
      'system-hostname': 'unknown',
      'system-rootname': 'unknown',
      'system-starttime': '0',
      'system-pms': 'unknown',
      'system-uname': 'unknown'
    };
    try {
      try {
        const { stdout: kernel } = await execAsync('uname -r');
        result['system-kernel'] = kernel.trim();
      } catch (e) {
        result['system-kernel'] = 'unknown';
      }
      try {
        const osRelease = await fs.readFile('/etc/os-release', 'utf8');
        const lines = osRelease.split('\n');
        let name = '';
        let version = '';
        for (const line of lines) {
          if (line.startsWith('NAME=')) {
            name = line.split('=')[1].replace(/"/g, '').trim();
          }
          if (line.startsWith('VERSION=')) {
            version = line.split('=')[1].replace(/"/g, '').trim();
          }
          if (line.startsWith('PRETTY_NAME=')) {
            const pretty = line.split('=')[1].replace(/"/g, '').trim();
            if (!name) name = pretty;
          }
        }
        result['system-version'] = version ? (name + ' ' + version) : name;
      } catch (e) {
        try {
          const { stdout: lsb } = await execAsync('lsb_release -d -s 2>/dev/null || echo unknown');
          if (lsb.trim() !== 'unknown') {
            result['system-version'] = lsb.trim();
          }
        } catch (e2) {
        }
      }
      try {
        const { stdout: hostname } = await execAsync('hostname');
        result['system-hostname'] = hostname.trim();
      } catch (e) {
        result['system-hostname'] = 'unknown';
      }
      try {
        const { stdout: rootInfo } = await execAsync('id -nu 0 2>/dev/null || echo root');
        result['system-rootname'] = rootInfo.trim();
      } catch (e) {
        result['system-rootname'] = 'root';
      }
      try {
        const uptime = await fs.readFile('/proc/uptime', 'utf8');
        const seconds = Math.floor(parseFloat(uptime.split(' ')[0]));
        result['system-starttime'] = seconds.toString();
      } catch (e) {
        result['system-starttime'] = '0';
      }
      try {
        const pms = [];
        const checks = [
          { cmd: 'which apt', name: 'apt' },
          { cmd: 'which dpkg', name: 'dpkg' },
          { cmd: 'which opkg', name: 'opkg' },
          { cmd: 'which rpm', name: 'rpm' },
          { cmd: 'which yum', name: 'yum' },
          { cmd: 'which dnf', name: 'dnf' },
          { cmd: 'which pacman', name: 'pacman' },
          { cmd: 'which apk', name: 'apk' },
          { cmd: 'which emerge', name: 'emerge' },
          { cmd: 'which zypper', name: 'zypper' }
        ];
        for (const check of checks) {
          try {
            const { stdout } = await execAsync(check.cmd + ' 2>/dev/null');
            if (stdout.trim()) {
              pms.push(check.name);
            }
          } catch (e) {
          }
        }
        result['system-pms'] = pms.length > 0 ? pms.join('/') : 'unknown';
      } catch (e) {
        result['system-pms'] = 'unknown';
      }
      try {
        const { stdout: uname } = await execAsync('uname -a');
        result['system-uname'] = uname.trim();
      } catch (e) {
        result['system-uname'] = 'unknown';
      }
      return result;
    } catch (err) {
      throw new Error('Failed to get System information: ' + err.message);
    }
  }
};
