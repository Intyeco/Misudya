/*
Misudya RAM Information Return

API: /getinfo
VALVE: 
AUTHOR: Reyrmth
LATETIME: 20260419/1:07:44 UTC+8
*/

const fs = require('fs').promises;
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
module.exports = {
  route: '/raminfo',
  async execute(query, method, context) {
    const result = {
      'ram-usage': '0%',
      'ram-type': 'unknown',
      'ram-speed': 'unknown',
      'ram-hightasks': 'none',
      'ram-model': 'unknown'
    };
    try {
      try {
        const data = await fs.readFile('/proc/meminfo', 'utf8');
        const lines = data.split('\n');
        let total = 0;
        let free = 0;
        let available = 0;
        for (const line of lines) {
          const parts = line.split(':');
          if (parts.length === 2) {
            const key = parts[0].trim();
            const value = parseInt(parts[1].trim()) || 0;
            if (key === 'MemTotal') total = value;
            if (key === 'MemFree') free = value;
            if (key === 'MemAvailable') available = value;
          }
        }
        if (total > 0) {
          const used = total - available;
          const usage = ((used / total) * 100).toFixed(0);
          result['ram-usage'] = usage + '%';
        }
      } catch (e) {
        result['ram-usage'] = 'error';
      }
      try {
        const { stdout: dmidecode } = await execAsync('dmidecode -t memory 2>/dev/null || echo "NO_SUDO"');
        if (dmidecode !== 'NO_SUDO\n') {
          const lines = dmidecode.split('\n');
          let type = 'unknown';
          let speed = 'unknown';
          let manufacturer = 'unknown';
          let partNumber = 'unknown';
          for (const line of lines) {
            if (line.includes('Type:') && !line.includes('Type Detail:')) {
              const match = line.match(/Type:\s*(.+)/);
              if (match && match[1] !== 'Unknown') {
                type = match[1].trim();
              }
            }
            if (line.includes('Speed:') || line.includes('Configured Clock Speed:')) {
              const match = line.match(/(?:Speed|Configured Clock Speed):\s*(\d+)\s*MHz/);
              if (match) {
                speed = match[1] + 'MHz';
              }
            }
            if (line.includes('Manufacturer:')) {
              const match = line.match(/Manufacturer:\s*(.+)/);
              if (match && match[1] !== 'Not Specified' && match[1] !== 'NO DIMM') {
                manufacturer = match[1].trim();
              }
            }
            if (line.includes('Part Number:')) {
              const match = line.match(/Part Number:\s*(.+)/);
              if (match && match[1] !== 'Not Specified' && match[1] !== 'NO DIMM') {
                partNumber = match[1].trim();
              }
            }
          }
          result['ram-type'] = type;
          result['ram-speed'] = speed;
          result['ram-model'] = (manufacturer + ' ' + partNumber).trim() || 'unknown';
        } else {
          try {
            const { stdout: memInfo } = await execAsync('cat /proc/device-tree/memory*/name 2>/dev/null || cat /sys/firmware/devicetree/base/memory*/device_type 2>/dev/null || echo "unknown"');
            if (memInfo && memInfo !== 'unknown') {
              result['ram-type'] = 'Embedded';
            }
          } catch (e) {
          }
        }
      } catch (e) {
        result['ram-type'] = 'unknown';
      }
      try {
        const { stdout } = await execAsync('ps aux --sort=-%mem | head -2 | tail -1');
        const parts = stdout.trim().split(/\s+/);
        if (parts.length >= 11) {
          const command = parts.slice(10).join(' ');
          result['ram-hightasks'] = command.length > 20 ? command.substring(0, 20) + '...' : command;
        } else {
          result['ram-hightasks'] = 'none';
        }
      } catch (e) {
        result['ram-hightasks'] = 'unknown';
      }
      return result;
    } catch (err) {
      throw new Error('Failed to get RAM information: ' + err.message);
    }
  }
};
