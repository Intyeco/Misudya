/*
Misudya Developer Test Library

API: /test
VALVE: 
AUTHOR: Reyrmth
LATETIME: 20260418/23:51:59 UTC+8
*/

module.exports = {
  route: '/test',
  execute(query, method, context) {
    return {
      status: 'ok',
      message: 'Connect Successfully',
      debug: context.debug,
      timestamp: new Date().toISOString()
    };
  }
};
