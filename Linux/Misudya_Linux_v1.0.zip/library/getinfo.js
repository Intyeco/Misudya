/*
Misudya Get Device Info

API: /getinfo
VALVE: 
AUTHOR: Reyrmth
LATETIME: 20260419/1:07:44 UTC+8
*/

const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const fs = require('fs').promises;

module.exports = {
  route: '/getinfo',
  async execute(query, method, context) {
    const result = {
      'cpu-usage': '0%',
      'ram-usage': '0%',
      'space': '0%',
      'hostname': 'unknown'
    };
    try {
      try {
        const getCpuStat = async () => {
          const data = await fs.readFile('/proc/stat', 'utf8');
          const line = data.split('\n')[0];
          const parts = line.trim().split(/\s+/).slice(1).map(Number);
          return {
            user: parts[0],
            nice: parts[1],
            system: parts[2],
            idle: parts[3],
            iowait: parts[4],
            irq: parts[5],
            softirq: parts[6]
          };
        };
        const stat1 = await getCpuStat();
        await new Promise(r => setTimeout(r, 500));
        const stat2 = await getCpuStat();
        const total1 = stat1.user + stat1.nice + stat1.system + stat1.idle + stat1.iowait + stat1.irq + stat1.softirq;
        const total2 = stat2.user + stat2.nice + stat2.system + stat2.idle + stat2.iowait + stat2.irq + stat2.softirq;
        const totalDiff = total2 - total1;
        const idleDiff = stat2.idle - stat1.idle;
        const usage = totalDiff > 0 ? ((totalDiff - idleDiff) / totalDiff * 100).toFixed(0) : 0;
        result['cpu-usage'] = usage + '%';
      } catch (e) {
        result['cpu-usage'] = 'error';
      }
      try {
        const data = await fs.readFile('/proc/meminfo', 'utf8');
        const lines = data.split('\n');
        let total = 0;
        let available = 0;
        for (const line of lines) {
          if (line.startsWith('MemTotal:')) {
            total = parseInt(line.match(/\d+/)[0]);
          }
          if (line.startsWith('MemAvailable:')) {
            available = parseInt(line.match(/\d+/)[0]);
          }
        }

        if (total > 0) {
          const used = total - available;
          const usage = ((used / total) * 100).toFixed(0);
          result['ram-usage'] = usage + '%';
        }
      } catch (e) {
        result['ram-usage'] = 'error';
      }
      try {
        const { stdout } = await execAsync('df -h / | tail -1');
        const parts = stdout.trim().split(/\s+/);
        if (parts.length >= 5) {
          result['space'] = parts[4];
        }
      } catch (e) {
        result['space'] = 'error';
      }
      try {
        const { stdout } = await execAsync('hostname');
        result['hostname'] = stdout.trim();
      } catch (e) {
        result['hostname'] = 'unknown';
      }
      return result;
    } catch (err) {
      throw new Error('Failed to get information: ' + err.message);
    }
  }
};
