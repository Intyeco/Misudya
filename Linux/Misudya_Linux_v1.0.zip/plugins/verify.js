const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
class Verify {
  constructor() {
    this.keyPath = path.join(process.cwd(), 'key.conf');
    this.validKey = null;
    this.loadKey();
  }
  loadKey() {
    try {
      if (!fs.existsSync(this.keyPath)) {
        console.error('[F A I L] Not found key.conf, is that created?');
        process.exit(1);
      } 
      const key = fs.readFileSync(this.keyPath, 'utf8').trim();
      if (!/^[a-zA-Z0-9]{40}$/.test(key)) {
        console.error('[F A I L] Key is not able for Misudya Security, ensure it have 40 chars!');
        process.exit(1);
      }
      this.validKey = key;
    } catch (err) {
      console.error('[F A I L] Failed to load Misudya Key: ', err.message);
      process.exit(1);
    }
  }
  verify(queryKey) {
    if (!queryKey || typeof queryKey !== 'string') {
      return { valid: false, reason: 'No Key Found' };
    }
    const keyBuf = Buffer.from(queryKey);
    const validBuf = Buffer.from(this.validKey);

    if (keyBuf.length !== validBuf.length) {
      return { valid: false, reason: 'Key Length Error' };
    }
    try {
      const match = crypto.timingSafeEqual(keyBuf, validBuf);
      return match 
        ? { valid: true } 
        : { valid: false, reason: 'Key is incorrect' };
    } catch {
      return { valid: false, reason: 'Failed to check key' };
    }
  }
  reload() {
    console.log('[W A R N] Reloaded Key');
    this.loadKey();
  }
}
module.exports = Verify;
