const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');
class Request {
  constructor(misudya) {
    this.misudya = misudya;
    this.server = null;
    this.port = 8443;
  }
  start() {
    const certsDir = path.join(process.cwd(), 'certs');
    if (!fs.existsSync(path.join(certsDir, 'server.key')) ||
        !fs.existsSync(path.join(certsDir, 'server.crt'))) {
      console.error('[Request] 证书文件缺失，请放置到 certs/ 目录');
      process.exit(1);
    }
    const options = {
      key: fs.readFileSync(path.join(certsDir, 'server.key')),
      cert: fs.readFileSync(path.join(certsDir, 'server.crt')),
      minVersion: 'TLSv1.2'
    };
    this.server = https.createServer(options, (req, res) => {
      this.handleRequest(req, res);
    });
    this.server.listen(this.port, () => {
      console.log(`[Request] HTTPS服务启动，端口 ${this.port}`);
    });
    this.server.on('error', (err) => {
      console.error('[Request] 服务器错误:', err.message);
    });
  }
  handleRequest(req, res) {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    if (!['GET', 'POST'].includes(req.method)) {
      this.sendError(res, 405, '仅支持GET/POST');
      return;
    }
    const parsed = url.parse(req.url, true);
    const query = parsed.query;
    if (!query.name || !query.key) {
      this.sendError(res, 400, '缺少必要参数: name, key');
      return;
    }
    this.misudya.route(query, req.method, res);
  }
  sendError(res, code, message) {
    res.statusCode = code;
    res.end(JSON.stringify({ error: message }));
  }
  sendSuccess(res, data) {
    res.statusCode = 200;
    res.end(JSON.stringify({ success: true, data }));
  }
  stop() {
    if (this.server) {
      this.server.close();
      console.log('[W A R N] Request Service stopped!');
    }
  }
}
module.exports = Request;