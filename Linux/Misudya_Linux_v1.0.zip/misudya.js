const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const url = require('url');
class Misudya {
  constructor() {
    this.debug = 0;
    this.plugins = {};
    this.commands = [];
    this.port = 8443;
    this.init();
  }
  init() {
    console.log(`Starting up Misudya service(s)...`);
    this.loadPlugins();
    this.scanLibrary();
    this.startServer();
  }
  loadPlugins() {
    const pluginsDir = path.join(__dirname, 'plugins');
    if (!fs.existsSync(pluginsDir)) {
      console.error('[F A I L] Cannot search "plugins" folder!');
      process.exit(1);
    }
    const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'));
    for (const file of files) {
      const name = path.basename(file, '.js');
      const PluginClass = require(path.join(pluginsDir, file));
      this.plugins[name] = new PluginClass(this);
      console.log(`[D O N E] Launched plugin: ${name}`);
    }
    if (!this.plugins.verify) {
      console.error('[F A I L] Failed to load VERIFY services!');
      process.exit(1);
    }
  }
  scanLibrary() {
    const libDir = path.join(__dirname, 'library');
    if (!fs.existsSync(libDir)) {
      fs.mkdirSync(libDir, { recursive: true });
      return;
    }
    const files = fs.readdirSync(libDir).filter(f => f.endsWith('.js'));
    for (const file of files) {
      const filePath = path.join(libDir, file);
      delete require.cache[require.resolve(filePath)];
      const commandModule = require(filePath);
      const name = path.basename(file, '.js');
      if (!commandModule.route) {
        console.warn(`[F A I L] Cannot load library: ${file} by NOT_HAVE_ROUTER_DEFINITION`);
        continue;
      }
      if (typeof commandModule.execute !== 'function') {
        console.warn(`[F A I L] Cannot load library: ${file} by NOT_HAVE_EXCUTE_FUNCTION`);
        continue;
      }
      this.commands.push({
        name: name,
        file: file,
        route: commandModule.route,
        execute: commandModule.execute
      });
      console.log(`[D O N E] Launched library: ${name}`);
    }

    console.log(`[D O N E] Loaded ${this.commands.length} library(ies)!`);
  }
  startServer() {
    const handler = (req, res) => this.handleRequest(req, res);
    if (this.debug === 1) {
      this.server = http.createServer(handler);
      console.log('[W A R N] You are running with DEBUG-MODE, and it use HTTP, be careful with your privacy!');
    } else {
      const certsDir = path.join(process.cwd(), 'certs');
      const keyPath = path.join(certsDir, 'server.key');
      const certPath = path.join(certsDir, 'server.crt');
      
      if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
        console.error('[F A I L] Cannot Open CERTS, please put HTTPS-CERTS into /certs or open DEBUG-MODE!');
        process.exit(1);
      }
      const options = {
        key: fs.readFileSync(keyPath),
        cert: fs.readFileSync(certPath),
        minVersion: 'TLSv1.2'
      };
      this.server = https.createServer(options, handler);
      console.log('[D O N E] Starting up service');
    }
    this.server.listen(this.port, () => {
      console.log(`[D O N E] Open HTTPS service at port ${this.port}`);
    });
    this.server.on('error', (err) => {
      console.error('[F A I L] Failed to open serice: ', err.message);
    });
  }
  handleRequest(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
      res.statusCode = 204;
      res.end();
      return;
    }
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('X-Content-Type-Options', 'nosniff');

    if (!['GET', 'POST'].includes(req.method)) {
      this.sendError(res, 405, '仅支持GET/POST');
      return;
    }
    const parsed = url.parse(req.url, true);
    const pathname = parsed.pathname;
    const query = parsed.query;
    if (!query.key) {
      this.sendError(res, 400, '缺少必要参数: key');
      return;
    }
    const verifyResult = this.plugins.verify.verify(query.key);
    if (!verifyResult.valid) {
      this.sendError(res, 403, `验证失败: ${verifyResult.reason}`);
      return;
    }
    const matchedCommand = this.findCommand(pathname, query);
    if (!matchedCommand) {
      this.sendError(res, 404, `无匹配路由: ${pathname}`);
      return;
    }
    this.executeCommand(matchedCommand, query, req.method, res, pathname);
  }
  findCommand(pathname, query) {
    for (const cmd of this.commands) {
      const route = cmd.route;
      let matched = false;
      if (typeof route === 'string') {
        matched = (pathname === route || pathname.startsWith(route + '/'));
      } else if (route instanceof RegExp) {
        matched = route.test(pathname);
      } else if (typeof route === 'function') {
        matched = route(pathname, query);
      }
      
      if (matched) {
        return cmd;
      }
    }
    return null;
  }
  executeCommand(command, query, method, res, pathname) {
    try {
      const context = {
        name: command.name,
        pathname: pathname,
        debug: this.debug
      };

      const result = command.execute(query, method, context);
      
      Promise.resolve(result)
        .then(data => {
          this.sendSuccess(res, data);
        })
        .catch(err => {
          console.error(`[F A I L] Cannot run command: [${command.name}], `, err, `, please ensure you have ROOT`);
          this.sendError(res, 500, err.message);
        });
        
    } catch (err) {
      console.error(`[F A I L] Cannot open [${command.name}]:`, err);
      this.sendError(res, 500, err.message);
    }
  }

  sendError(res, code, message) {
    res.statusCode = code;
    res.end(JSON.stringify({ error: message, timestamp: Date.now() }));
  }

  sendSuccess(res, data) {
    res.statusCode = 200;
    res.end(JSON.stringify({ success: true, data, timestamp: Date.now() }));
  }

  reloadLibrary() {
    this.commands = [];
    this.scanLibrary();
    return { reloaded: this.commands.length };
  }

  shutdown() {
    console.log('Stopping service...');
    if (this.server) {
      this.server.close();
    }
    process.exit(0);
  }
}

process.on('SIGTERM', () => app.shutdown());
process.on('SIGINT', () => app.shutdown());

const app = new Misudya();
